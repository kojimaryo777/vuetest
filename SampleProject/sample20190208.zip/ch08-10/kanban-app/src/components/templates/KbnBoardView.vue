<template>
  <p>ボードページ</p>
</template>

<script>
/* eslint-disable */
export default {
  name: 'KbnBoardView',

  /* NOTE: ErrorBoundary の動作確認ためのコード
  render (h) {
    throw new Error('レンダリングに失敗しました！')
  }
  */
}
/* eslint-enable */
</script>
