<template>
  <h2>このページはNuxt社のトップのページです。</h2>
</template>
