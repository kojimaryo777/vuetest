<template>
  <h2>このページはNuxt社の企業情報のページです。</h2>
</template>
