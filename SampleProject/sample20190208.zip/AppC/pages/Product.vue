<template>
  <h2>このページはNuxt社のプロダクト情報のページです。</h2>
</template>

