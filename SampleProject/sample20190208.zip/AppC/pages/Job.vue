<template>
  <h2>このページはNuxt社の採用情報のページです。</h2>
</template>
